import numpy as np

# 21能够收敛，但是太扯了，所以得试试其它靠谱方法
class EnvCore(object):
    """
    # 环境中的智能体
    """

    def __init__(self, i):
        self.agent_num = i  # 设置智能体的个数
        self.obs_dim = 3  # 根据论文里面obs_dim = 1，意义是该智能体连续不当领导人的次数
        self.action_dim = 2  # 根据论文里面action_dim =2 只有两种选择，发或者不发信息
        self.channel_utilization_index = np.zeros((self.agent_num), dtype=np.float32)
        self.observation_space = [3 for _ in range(self.agent_num)]
        self.last_success_cui_norm = 0

    def reset(self):
        self.channel_utilization_index = np.zeros((self.agent_num), dtype=np.float32)
        norm_cui = np.expand_dims(self.channel_utilization_index, 1)
        sub_agent_obs = np.concatenate(
            (
                norm_cui,
                np.zeros_like(norm_cui),
                np.zeros_like(norm_cui),
            ),
            axis=1,
        )
        return sub_agent_obs

    def step(self, actions_):
        """

        parameters:
        ------
        actions: should be a list of action, e.g. [1,0,1,0,1] 1 indicates the agent sends a message and 0 indicates the agent does not send a message

        returns:
        -------
        obs: next observation
        reward: the reward of each agent
        done: whether the episode is done
        info: information about the episode
        """
        # 首先定义一系列的返回值
        sub_agent_obs = []
        sub_agent_reward = []
        sub_agent_done = []
        sub_agent_info = []
        # 首先根据action判断这一轮的领导人选举是否成功
        actions = [1 if action[0] == 0 else 0 for action in actions_]
        # update send count
        success, leader_index, dist_from_success = self._Ct(actions)

        # compute reward
        for i in range(self.agent_num):
            if success:
                # 如果成功的话，是领导人的那个加分
                if i == leader_index:
                    r = 10
                # 不该发的发了
                elif (
                    self.channel_utilization_index[i]
                    > self.channel_utilization_index[leader_index]
                    and actions[i] == 1
                ):
                    r = 1
                # 不该发的没发
                elif (
                    self.channel_utilization_index[i]
                    <= self.channel_utilization_index[leader_index]
                    and actions[i] == 0
                ):
                    r = 5
                # 该发的没发
                elif (
                    self.channel_utilization_index[i]
                    > self.channel_utilization_index[leader_index]
                    and actions[i] == 0
                ):
                    r = 1
                else:
                    print("else triggered")
                    r = 0
            # 失败的情况
            else:
                # 不该发的瞎几把发
                if (
                    self.channel_utilization_index[i] > self.last_success_cui_norm - 1
                    and actions[i] == 1
                ):
                    r = -5 - (dist_from_success if dist_from_success > 0 else 0)
                # 该发的没发
                elif (
                    self.channel_utilization_index[i] <= self.last_success_cui_norm - 1
                    and actions[i] == 0
                ):
                    r = -5 + 10 * (dist_from_success if dist_from_success < 0 else 0)
                elif (
                    self.channel_utilization_index[i] > self.last_success_cui_norm - 1
                    and actions[i] == 1
                ):
                    r = -1
                else:
                    r = -1
            sub_agent_reward.append([r])

        # 如果成功了 我们还要更新状态
        if success:
            self.last_success_cui_norm = (
                self.channel_utilization_index[leader_index] + 1
            )

            # if success, we update the state of each agent
            self.channel_utilization_index += 1
            self.channel_utilization_index[leader_index] = 0

        # norm_cui.shape is (num_agent,1)
        norm_cui = np.expand_dims(self.channel_utilization_index, 1)
        sub_agent_obs = np.concatenate(
            (
                norm_cui,
                np.ones_like(norm_cui) * self.last_success_cui_norm,
                np.ones_like(norm_cui) * sum(actions),
            ),
            axis=1,
        )

        sub_agent_done = [False for _ in range(self.agent_num)]
        sub_agent_info = success
        return [sub_agent_obs, sub_agent_reward, sub_agent_done, sub_agent_info]

    def _Ct(self, actions: list[int]) -> tuple:
        if sum(actions) == 1:
            return True, actions.index(1), None
        else:
            dist_from_success = sum(actions) - 1
            return False, None, dist_from_success

    def _get_mean_cui(self):
        return np.mean(self.channel_utilization_index)

    def _get_max_cui(self):
        return np.max(self.channel_utilization_index)


# 测试
if __name__ == "__main__":
    env = EnvCore(5)

    s = env.reset()

    print(s)

    obs_next, r, _, _ = env.step([[1, 0], [1, 0], [0, 1], [1, 0], [1, 0]])
    obs_next, r, _, _ = env.step([[1, 0], [1, 0], [0, 1], [1, 0], [1, 0]])
    print(obs_next, r)
