#!/usr/bin/bash
rm -r /home/ubuntu/skshen/code/light_mappo/results 