#!/usr/bin/bash
source /home/ubuntu/anaconda3/bin/activate mappo

echo "use cuda $1"
#python train/train.py  --env_name EnvCore --share_policy --use_centralized_V --use_eval --eval_interval 50 --eval_episodes 10 --gamma 0.9 --use_feature_normalization --num_agents 3
CUDA_VISIBLE_DEVICES=$1 python train/train.py  \
--env_name EnvCore \
--share_policy \
--use_centralized_V \
--gamma 0.90 \
--use_feature_normalization \
--num_agents 100 \
--entropy_coef 0.05 \
--seed 1 \
--n_training_threads 10 \
--n_rollout_threads 10 \
--use_ReLU \
--use_recurrent_policy \
--algorithm_name rmappo \