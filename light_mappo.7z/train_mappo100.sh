#!/usr/bin/bash
source /home/ubuntu/anaconda3/bin/activate mappo

echo "use cuda $1"
#python train/train.py  --env_name EnvCore --share_policy --use_centralized_V --use_eval --eval_interval 50 --eval_episodes 10 --gamma 0.9 --use_feature_normalization --num_agents 3
CUDA_VISIBLE_DEVICES=$1 python train/train.py \
  --env_name MAPPO100v21 \
  --share_policy \
  --use_centralized_V \
  --gamma 0.0 \
  --use_feature_normalization \
  --num_agents 100 \
  --entropy_coef 0.01 \
  --seed 114514 \
  --n_training_threads 20 \
  --n_rollout_threads 40 \
  --use_ReLU \
  --algorithm_name mappo \
  --model_dir results/MAPPO100v21/MyEnv/mappo/MARL/run2/models
#  --use_eval \
#  --eval_interval 10 \
#  --eval_episodes 5 \
